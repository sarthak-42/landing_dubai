import React from "react";
import Rating from "@mui/material/Rating";
export default function InfoCard() {
  return (
    <div className="px-5">
      <div className="card px-" style={{ width: "20rem" }}>
        <img
          src="https://cdn.yourholiday.me/static/dynimg/itinerary/77/600x300/2211593-2211592_dubai-6.jpg"
          className="card-img-top"
          alt="..."
          height={250}
        />
        <div className="card-body">
          <h5 className="card-title">Card title</h5>
          <p className="card-text">
            Some quick example text to build on the card title and make up the
            bulk of the card's content.
          </p>
        </div>
        {/* <ul className="list-group list-group-flush">
      <li className="list-group-item">An item</li>
      <li className="list-group-item">A second item</li>
      <li className="list-group-item">A third item</li>
    </ul> */}
        <div className="card-body d-flex justify-content-evenly align-items-center ">
          <Rating name="read-only" value={3} readOnly />
          <div className="container d-flex justify-content-end">
            Starting From
            <br></br>
            Random price
          </div>
        </div>
      </div>
    </div>
  );
}
