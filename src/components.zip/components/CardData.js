const cardData = [
    {
        category: "Bestsellers",
        imageUrl: "https://cdn.yourholiday.me/static/dynimg/itinerary/77/600x300/2211593-2211592_dubai-6.jpg",
        title: "Dubai Basic for First TImers",
        description: "Dubai 4N",
        rating: "3",
        price: "₹16,699"        
    }
]