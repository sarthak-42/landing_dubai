import React from 'react'
// import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Navbar from '../Navbar'
import InfoCard from '../InfoCard'
const Home = () => {
  return (
    // console.log("Home")
   <>
   
   <Navbar/>
   <InfoCard/>
   </>

    // <Route path = "/" exact element={<Navbar/>}></Route>
   
  )
}

export default Home